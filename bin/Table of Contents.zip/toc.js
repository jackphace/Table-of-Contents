﻿//Settings provided by toc-controller.js:
//"collapseGroupHotkey", "currentHotkey", "headingOffset", "nextHotkey", "previousHotkey", "scrollSpeed", "tocHotkey", "toggleSpeed"

//Default settings not handled in chrome storage/options page
var linkHeight = '17px';
var prefix = 'toc';
var togglePrefix = 'toggle';
var linkPrefix = 'link';
var groupPrefix = 'group';
var selectors = 'h1,h2,h3,h4,h5,h6';
var hoverableSelectors = 'div,body,html';
var selectParentHotkey = 'b';

//Based off prop('tagName') of headers
//The level of headings used for nesting
var headingLevels = {
    "H1": 0,
    "H2": 1,
    "H3": 2,
    "H4": 3,
    "H5": 4,
    "H6": 5
};

//Number of divs open at a particular depth, indexed by heading level
var openDivs = [];
for (var h in headingLevels) {
    openDivs[headingLevels[h]] = 0;
}

//Build the table of contents
function buildToC(container) {
    //Only execute if a table of contents hasn't been built already
    if (document.getElementById("toc-side") !== null) {
        console.log("Table of contents already created.");
        return;
    }
    else {
        //Hotkey only builds ToC one time
        Mousetrap.unbind(tocHotkey);

        //Add side bar and wrapper for ToC links
        $('body').append('<div id="toc-side"><div class="toc" id="toc-wrapper"></div></div>');

        //Find all matched selectors
        var headings;
        if (arguments.length > 0)
            headings = $(container).find(selectors);
        else
            headings = $(selectors);

        //Get the number of digits in the ToC to be made to figure out length of accelerators
        var digits = numDigits(headings.length);

        var toc = $('#toc-wrapper');
        var tocHtml = '';

        //For each heading...
        headings.each(function (i, header) {
            //Find header to be linked to in table of contents
            var h = $(header);

            //Add anchor to DOM before the header linked to
            var anchor = '<a id="' + prefix + i + '"></a>';
            $(h).before(anchor);

            //Find the type of tag the header is
            var tagType = h.prop('tagName');

            //Close all divs that are open at the same or lower levels than the current heading level
            var closeDivs = "";
            var closed = 0;
            for (var l = headingLevels[tagType]; l < openDivs.length; l++) {
                //Add number of divs open at level
                for (var j = 0; j < openDivs[l]; j++) {
                    closeDivs += "</div>";
                    closed++;
                }

                //Clear div count
                openDivs[l] = 0;
            }
            //Add closed divs to close to DOM
            tocHtml += closeDivs;

            //Wrap this table of contents group in a div
            tocHtml += '<div class="toc-group" id="' + groupPrefix + i + '">';

            //Incrememnt number of open divs at appropriate level
            openDivs[headingLevels[tagType]]++;

            //Add a collapse toggle
            tocHtml += '<div class="' + togglePrefix + tagType + ' toc-toggle toc-childless"></div>';

            //Add an anchor in the table of contents of the corresponding class to scroll to the other anchor
            var link = '<a class="' + prefix + tagType + '" id="' + linkPrefix + i + '" href="#' + prefix + i + '">' + h.text() + '</a>';
            tocHtml += link;

            //Get the accelerator shortcut text for the current header
            var accelText = getHotkeyText(digits, i);
            tocHtml += accelText;
        });

        //Close all unclosed divs at any depth
        var closeDivs = "";
        for (var h in headingLevels) {
            for (var i = 0; i < openDivs[headingLevels[h]]; i++) {
                closeDivs += "</div>";
            }
        }
        tocHtml += closeDivs;

        //Add the table of contents to the wrapper
        $('#toc-wrapper').html(tocHtml);

        //For each link, set up the click / keyboard shortcut functionality
        $('#toc-wrapper a').each(function (index, link) {
            $(link).click(function () {
                //Add scrolling to link
                $.scrollTo('#' + prefix + index, scrollSpeed, { easing: 'swing' });

                //Remove any link that is in the active state, add this as active
                $('#toc-wrapper a.active').removeClass('active');
                $(link).addClass('active');

                //Expand all parent groups to ensure this group is visible
                $(link).parents('#toc-wrapper .toc-group').each(
                    function (index, parentGroup) {
                        expandSection(parentGroup);
                    });

                //Disable default click navigation to link (which make stuff blink)
                return false;
            });

            addHotkey(digits, index);
        });

        //Indent the toggles to indicate depth

        //Set first link in table of contents as the active one
        $('#toc-wrapper a').first().addClass('active');

        //Add collapsible regions to each link group with children groups
        $('#toc-wrapper div.toc-group').each(
            function (index, group) {
                //If the group has one or more child groups...
                if ($(group).children('.toc-group').length > 0) {
                    //Remove from the groups toggle the default class, add expanded class, add click function
                    var toggle = $(group).children('.toc-toggle');
                    toggle
                    .removeClass('toc-childless')
                    .addClass('toc-expanded')
                    .click(function () {
                        //Expand or collapse group depending on state
                        if (toggle.hasClass('toc-expanded')) {
                            collapseSection(group, toggle);
                        }
                        else if (toggle.hasClass('toc-collapsed')) {
                            expandSection(group, toggle);
                        }
                    });
                }
            });

        //Change build table of contents hotkey to toggle
        Mousetrap.bind(tocHotkey, toggleToC);

        //Add accelerators for next / previous / current link navigation
        console.log("binding hotkeys:" + nextHotkey + currentHotkey + previousHotkey + collapseGroupHotkey);
        Mousetrap.bind(nextHotkey, function () { moveSection(1); });
        Mousetrap.bind(currentHotkey, function () { moveSection(0); });
        Mousetrap.bind(previousHotkey, function () { moveSection(-1); });
        Mousetrap.bind(collapseGroupHotkey, function () {
            toggleCurrentSection();
        });
    }
}

//Add border to hovered element. After click, choose select element.
function chooseContainer() {
    //Set any currently hovered items to proper state..?
    //TODO. ASK SMARTER PEOPLE.

    //Delete table of contents to allow reselection..?

    //Next click chooses the hovered container to build ToC on
    $(document).on('click.chooseContainer', function (e) {
        //Stop other click events from being triggered
        e.stopPropagation();        //Might make more sense to do hovering top level using this

        //Get rid of parent selection hotkey
        Mousetrap.unbind(selectParentHotkey);

        var container = $(hoverableSelectors).find('.toc-hovered');

        if (container.length === 1) {
            console.log('Building table of contents in container ' + container);
            buildToC(container);
        }
        else {
            console.log('Building table of contents with no container.');
            buildToC();
        }

        //Remove toc-hovered from all hoverable
        var hoverable = $(hoverableSelectors).removeClass('toc-hovered');

        //Remove click functionality using event namespacing
        //http://stackoverflow.com/questions/209029/best-way-to-remove-an-event-handler-in-jquery
        $(document).off('click.chooseContainer');
        $(hoverableSelectors).off('mouseover.hover').off('mouseout.hover');
    });

    //Add Mouse event to move up the selected items parent tree
    Mousetrap.bind(selectParentHotkey, function () {
        //Possibly remove hover thingy here..?
        //MAYBE TODO

        //Move up tree with sexy jQuery string
        //Might stop propagation at top level..? Has the same effect
        $(hoverableSelectors).find('.toc-hovered').removeClass('toc-hovered').parent().addClass('toc-hovered');
    });

    //Display hover stripes over the deepest item selected.
    $(hoverableSelectors)
        .on('mouseover.hover',
        //On mouse over
        function () {
            console.log('hovering over: ' + $(this).parents().length);
            //Workaround for broken :hover pseudo in jQuery 1.91
            $(this).addClass('hover');

            highlightDeepestHoverable();
        })
        .on('mouseout.hover',
        //On mouse out
        function () {
            $(this).removeClass('hover');

            highlightDeepestHoverable();
        });
    //$(hoverableSelectors)
    //    .hover(
    //    //On mouse over
    //    function () {
    //        console.log('hovering over: ' + $(this).parents().length);
    //        //Workaround for broken :hover pseudo in jQuery 1.91
    //        $(this).addClass('hover');

    //        highlightDeepestHoverable();
    //    },
    //    //On mouse out
    //    function () {
    //        $(this).removeClass('hover');

    //        highlightDeepestHoverable();
    //    });

    //Get rid of hover events
    //$(hoverableSelectors).unbind('mouseenter mouseleave');
}

function highlightDeepestHoverable() {
    //Remove toc-hovered from all hoverable
    var hoverable = $(hoverableSelectors).removeClass('toc-hovered');

    //Add hover state only to deepest selector
    var deepestSection;
    var depth = 0;
    var hovered = hoverable.find('.hover');

    hovered.each(function (index, h) {
        var sectionDepth = $(h).parents().length;

        if (sectionDepth > depth) {
            depth = sectionDepth;
            deepestSection = h;
        }
    });

    $(deepestSection).addClass('toc-hovered');
}


//Toggle the expand state of the currently active group
function toggleCurrentSection() {
    var activeGroup = $('.toc-group a.active').parent();
    var activeToggle = activeGroup.children('.toc-toggle');

    if (activeToggle.hasClass('toc-expanded')) {
        collapseSection(activeGroup, activeToggle);
    }
    else if (activeToggle.hasClass('toc-collapsed')) {
        expandSection(activeGroup, activeToggle);
    }
}

function collapseSection(group, toggle) {
    //Get the toggle if it wasn't provided as an argument
    if (arguments.length < 2)
        toggle = $(group).children('.toc-toggle');

    //Only collapse if the state is expanded
    if ($(toggle).hasClass('toc-expanded')) {

        //Store the size of the expanded group
        $(group).data('originalHeight', $(group).height());

        //Collapse the group and change the toggle to collapsed
        $(group).animate(
        {
            //Use the outer height of the toggle..?
            //height: toggle.outerHeight()
            height: linkHeight
        }, toggleSpeed, function () {
            //Set class to collapsed on completion
            toggle
            .removeClass('toc-expanded')
            .addClass('toc-collapsed');
        });
    }
}

function expandSection(group, toggle) {
    //Get the toggle if it wasn't provided as an argument
    if (arguments.length < 2)
        toggle = $(group).children('.toc-toggle');

    //Only expand if the state is collapsed
    if ($(toggle).hasClass('toc-collapsed')) {
        $(group)
    .animate(
    {
        //Animate to old height
        height: $(group).data('originalHeight')
    }, toggleSpeed, function () {
        //Set class to collapsed on completion
        toggle
        .removeClass('toc-collapsed')
        .addClass('toc-expanded');

        //Remove the div's height attribute after animating so it doesn't cause gaps if children are collapsed
        $(group).css('height', '');
    });
    }
}

function moveSection(offset) {
    var links = $('#toc-wrapper a');

    //Make sure the offset is positive
    offset = ((offset % links.length) + links.length) % links.length;

    //Get the index of the active element in the table of contents
    var currentIndex = links.index($('#toc-wrapper a.active'));

    //No active element index found
    if (currentIndex === -1) {
        return false;
    }
    else {
        //Add offset
        currentIndex = (currentIndex + offset) % links.length;

        //Click on new active link
        links[currentIndex].click();
    }
}

function toggleToC() {
    $('#toc-side').animate(
        {
            width: 'toggle'
        }, toggleSpeed, function () {
            //Do nothing on finish
        });
}

function getHotkeyText(digits, index) {
    var zeroPaddedText = index.toString().lpad(digits, '0');
    var accelText = '<span class="toc-accelerator">' + zeroPaddedText + '</span>';

    return accelText;
}

function addHotkey(digits, index) {
    var zeroPaddedText = index.toString().lpad(digits, '0');

    //Add spaces between every character to create the accelerator shortcut
    var accelerator = zeroPaddedText[0];
    for (var i = 1; i < zeroPaddedText.length; i++) {
        accelerator += " " + zeroPaddedText[i];
    }

    Mousetrap.bind(accelerator, function (e) {
        $('#' + linkPrefix + index).click();
    });

    //return;
}

function log10(val) {
    return Math.log(val) / Math.LN10;
}

function numDigits(number) {
    return (number === 0) ? 1 : parseInt(log10(number),10) + 1;
}

String.prototype.lpad = function (length, padChar) {
    var s = this;
    while (s.length < length)
        s = padChar + s;
    return s;
};


