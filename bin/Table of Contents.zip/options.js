$(function () {
    //Don't reload page
    $('form').submit(function () { return false; });

    //Display slider values
    displayRanges();

    //Load existing values
    loadValues();

    //Click 'save' button to save values
    $('#save').click(saveOptions);
});



//Let the user know the value of the slider when it changes
function displayRanges() {
    $("input[type='range']").change(function () {
        var slider = $(this);
        slider.next("output").text(slider.val() + ' ms');
    })
    .trigger('change');
}

//Save out: scrollSpeed, toggleSpeed, headingOffset, prefix, linkPrefix, groupPrefix, selectors, tocHotkey, previousHotkey, currentHotkey, nextHotkey, collapseGroupHotkey
function saveOptions() {
    var output = 'Saving values...';
    $('#status').html(output);

    var valuesToSave = {};

    //Save out all non-null input
    $('input').each(function (i, el) {
        var key = el.name;
        var val = el.value;

        //Only add if the value exists. Possibly check for valid input here..? WHY WOULD PEOPLE RUIN THINGS FOR THEMSELVES THOUGH?! ;___;
        if (val) {
            valuesToSave[key] = val;
        }
    });

    // Save it using the Chrome sync storage API.
    //chrome.storage.local.set   -- 5mb of local storage
    //    for (key in valuesToSave)
    //        chrome.storage.sync.set({ key: valuesToSave[key] })
    chrome.storage.sync.set(valuesToSave, function () {
        output += '<br />Saved options successfully!';
        $('#status').html(output);

        //Don't reload page
        return false;
    });

    //Set is asynchronous, have to detect status of it I suppose
    //output += '<br />Save failed.';
    //$('#status').html(output);

    //Don't reload page
    return false;
}

//Loads previously saved values
function loadValues() {
    var valuesToLoad = [];

    //Request all elements that might have a storage value
    $('input').each(function (i, el) {
        valuesToLoad[i] = el.name;
    });

    chrome.storage.sync.get(valuesToLoad, function (items) {
        console.log(chrome.runtime.lastError === null);

        console.log(items);

        //'items' is the associative array of values for the inputs with the key name
        for (var key in items)
        {
            var input = $('#' + key);

            if (input.length === 1) {
                input.val(items[key]);
            }
        }

        //Set the range values
        //$("input[type='range']").each(function (i, el) {
        //    $(el).next('output').val($(el).val());
        //});
        $("input[type='range']").trigger('change');
    });
}