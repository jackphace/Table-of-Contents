﻿$(document).ready(function () {
    var path = chrome.extension.getURL('css/toc3.css');
    $('head').append($('<link>')
        .attr("rel", "stylesheet")
        .attr("type", "text/css")
        .attr("href", path));
});